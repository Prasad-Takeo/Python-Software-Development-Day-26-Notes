from django.http import HttpResponse
from .models import  Question
from django.shortcuts import render, get_object_or_404

#index page- latest few questions
#detail page - question text, form to vote
#results page - display results for a particular question
#Vote action - handles voting for the particular choice

def index(request):
    #get the top 5 question recently created
    latest_question_list = Question.objects.order_by("-pub_date")
    context = {
        "latest_question_list": latest_question_list
    }
    return render(request,"index.html",context)


def detail(request, question_id):#/polls/1, /polls/2
    question = get_object_or_404(Question,pk=question_id)
    return render(request,"details.html", {"question":question})

def results(request, question_id):
    response = "You're looking at the question %s"
    return HttpResponse(response % question_id)

def vote(request,question_id):
    return HttpResponse("You're voting on question %s" % question_id)


